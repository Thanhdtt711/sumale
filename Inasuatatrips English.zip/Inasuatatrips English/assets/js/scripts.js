
jQuery(document).ready(function () {
    //   Slide
    $('.slide').owlCarousel({
        items: 1,
        loop: true,
        nav: true,
        center: true,
        dots: true,
        navText: ['<img src="assets/img/icon/Stroke 1.png">', '<img src="assets/img/icon/Arrow - Right 2.png">'],
        responsiveClass: true,
        lazyContent: true,
        autoplay: true,
        autoplayTimeout: 8000,
        autoplayHoverPause: true,
    });
    $('.phanhoicr').owlCarousel({
        items: 3,
        loop: true,
        margin: 0,
        nav: true,
        dots: true,
        navText: ['<img src="assets/img/icon/Stroke 1.png">', '<img src="assets/img/icon/Arrow - Right 2.png">'],
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1,
                margin: 15
            },
            600: {
                items: 2,
                margin: 15,
            },
            1000: {
                items: 2,
                margin: 15,
            },
            1199: {
                items: 3,
                margin: 15,
            }
        }
    });
    $('.newss').owlCarousel({
        items: 3,
        loop: true,
        margin: 0,
        nav: true,
        dots: true,
        navText: ['<img src="assets/img/icon/Stroke 1.png">', '<img src="assets/img/icon/Arrow - Right 2.png">'],
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1,
                margin: 15
            },
            600: {
                items: 2,
                margin: 15,
            },
            1000: {
                items: 2,
                margin: 15,
            },
            1199: {
                items: 3,
                margin: 15,
            }
        }
    });
    $('.condoi').owlCarousel({
        items: 3,
        loop: true,
        margin: 0,
        nav: true,
        dots: false,
        navText: ['<img src="assets/img/icon/Stroke 1.png">', '<img src="assets/img/icon/Arrow - Right 2.png">'],
        responsiveClass: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1,
                margin: 15
            },
            600: {
                items: 2,
                margin: 15,
            },
            1000: {
                items: 2,
                margin: 15,
            },
            1199: {
                items: 3,
                margin: 15,
            }
        }
    });
    $('.hotels').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 5000,
        nav: false,
        dots: true,
        margin: 0,
        dotData: true,
        dotsData: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 1,
                nav: false
            },
            1200: {
                items: 1,
                nav: false
            }
        }
    });
    $('.hotel-lqs').owlCarousel({
        loop: true,
        autoplay: true,
        autoplayTimeout: 5000,
        nav: true,
        navText: ['<img src="assets/img/icon/Stroke 1.png">', '<img src="assets/img/icon/Arrow - Right 2.png">'],
        margin: 30,
        dots: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3,
                nav: false
            },
            1200: {
                items: 4,
            }
        }
    });
});
//Menu
jQuery(document).ready(function ($) {
    // script for menu mobile
    if ($(window).width() < 768) {
        var header = document.getElementById('header');
        header.classList.add("nav-top");
    }

    if ($(window).width() < 768) {
        var header = document.getElementById('header');
        header.classList.add("nav-top");
    }

    var navExpand = [].slice.call(document.querySelectorAll('.nav-expand'));

    navExpand.forEach(function (item) {
        item.querySelector('.nav-link').addEventListener('click', function () { return item.classList.add('active'); });
        item.querySelector('.nav-back-link').addEventListener('click', function () { return item.classList.remove('active'); });
    });

    // ---------------------------------------
    // not-so-important stuff starts here

    var ham = document.getElementById('ham');
    ham.addEventListener('click', function () {
        document.body.classList.toggle('nav-is-toggled');
    });

    var overlay = document.getElementById('overlay');
    overlay.addEventListener('click', function () {
        document.body.classList.toggle('nav-is-toggled');
    });

    $(document).on("click", ".nav-expand-link > i", function () {
        return false;
    });
});

// COUNTDOWN
(function () {
    const second = 1000,
        minute = second * 60,
        hour = minute * 60,
        day = hour * 24;

    let today = new Date(),
        dd = String(today.getDate()).padStart(2, "0"),
        mm = String(today.getMonth() + 1).padStart(2, "0"),
        yyyy = today.getFullYear(),
        nextYear = yyyy + 1,
        dayMonth = "11/07/",
        birthday = dayMonth + yyyy;

    today = mm + "/" + dd + "/" + yyyy;
    if (today > birthday) {
        birthday = dayMonth + nextYear;
    }
    const countDown = new Date(birthday).getTime(),
        x = setInterval(function () {

            const now = new Date().getTime(),
                distance = countDown - now;

            document.querySelector(".n").innerText = Math.floor(distance / (day)),
                document.querySelector(".h").innerText = Math.floor((distance % (day)) / (hour)),
                document.querySelector(".p").innerText = Math.floor((distance % (hour)) / (minute)),
                document.querySelector(".g").innerText = Math.floor((distance % (minute)) / second);

        }, 0)
}());

var ct = document.querySelectorAll('.programme-item p');
for (let index = 0; index < ct.length; index++) {
    ct[index].onclick = function (e) {
        ct[index].parentElement.classList.toggle("add-auto");
    };
};
var inputss = document.querySelector('#input1 img');
inputss.onclick = function () {
    inputss.parentElement.querySelector('.menu').classList.toggle('add-menus')
}

var inputsss = document.querySelector('#input2 img');
inputsss.onclick = function () {
    inputsss.parentElement.querySelector('.menu').classList.toggle('add-menus')
}


// MENU XEM THÊM
var xt = document.querySelector('.sumale');
xt.onclick = function (e) {
    document.querySelector('.calendar').classList.toggle("add");
};
